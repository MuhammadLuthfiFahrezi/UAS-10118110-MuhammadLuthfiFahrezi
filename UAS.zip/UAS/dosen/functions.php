<?php 

$conn = mysqli_connect("localhost", "root", "", "10118110_Akademik");


function query($query){
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}

	return $rows;
}

function tambah($data) {
	global $conn;
	$nip = htmlspecialchars($data["nip"]);
	$nama = htmlspecialchars($data["nama"]);

	$query = "INSERT INTO dosen VALUES ('', '$nip', '$nama')";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function hapus($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM dosen WHERE id = $id");
	return mysqli_affected_rows($conn);
}

function ubah($data) {
	global $conn;
	$id = $data["id"];
	$nip = htmlspecialchars($data["nip"]);
	$nama = htmlspecialchars($data["nama"]);

	$query = "UPDATE dosen SET 
				nip = '$nip',
				nama = '$nama'
				WHERE id = $id
				";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

 ?>