<?php 
require 'functions.php';
$dosen = query("SELECT * FROM dosen");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Dosen</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<center>
<h1 style="color: white">Daftar Dosen</h1>

<a href="tambah.php" style="color: white">Tambah Data Dosen</a>
<br><br>

<table border="1" cellpadding="10" cellspacing="0">
	
	<tr style="color: white">
		<th>No.</th>
		<th>Aksi</th>
		<th>NIP</th>
		<th>Nama</th>
	</tr>

<?php $i = 1; ?>
<?php foreach($dosen as $row) : ?>
	<tr>
		<td style="color: white"><?= $i; ?></td>
		<td>
			<a href="ubah.php?id=<?= $row["id"]; ?>" style="color: red; " >Ubah</a>
			<a href="hapus.php?id=<?= $row["id"]; ?>" style="color: red; ">Hapus</a>
		</td>
		<td style="color: white"><?= $row["nip"]; ?></td>
		<td style="color: white"><?= $row["nama"]; ?></td>
	</tr>
	<?php $i++; ?>
<?php endforeach; ?>
</table>
</center>
</body>
</html>