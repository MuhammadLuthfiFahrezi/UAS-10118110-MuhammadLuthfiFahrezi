<?php 
require 'functions.php';

$id = $_GET["id"];

$dsn = query("SELECT * FROM dosen WHERE id = $id")[0];

if( isset($_POST["submit"]) ){
	if( ubah($_POST) > 0) {
		echo "
		<script>
			alert('Data berhasil diubah');
			document.location.href = 'index.php';
		</script>
			";
	} else {
		echo "
		<script>
			alert('Data gagal diubah');
			document.location.href = 'index.php';
		</script>
			";
	}

}

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Ubah Data Dosen</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<h1>Ubah Data Dosen</h1>

	<form action="" method="post">
		<input type="hidden" name="id" value="<?= $dsn["id"]; ?>">
		<ul>
			<li>
				<label for="nip">NIP : </label>
				<input type="text" name="nip" id="nip" required value="<?= $dsn["nip"]; ?>">
			</li><br>
			<li>
				<label for="nama">Nama : </label>
				<input type="text" name="nama" id="nama" required value="<?= $dsn["nama"]; ?>">
			</li><br>
			<li>
				<button type="submit" name="submit">
					Ubah Data
				</button>
			</li>
		</ul>


	</form>

</body>
</html>