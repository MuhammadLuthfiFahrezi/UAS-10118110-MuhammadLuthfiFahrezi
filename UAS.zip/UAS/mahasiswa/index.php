<?php 
require 'functions.php';
$mahasiswa = query("SELECT * FROM mahasiswa");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<center>
<h1 style="color: white">Daftar Mahasiswa</h1>

<a href="tambah.php" style="color: white">Tambah Data Mahasiswa</a>
<br><br>

<table border="1" cellpadding="10" cellspacing="0">
	
	<tr style="color: white">
		<th>No.</th>
		<th>Aksi</th>
		<th>NIM</th>
		<th>Nama</th>
		<th>Semester</th>
	</tr>

<?php $i = 1; ?>
<?php foreach($mahasiswa as $row) : ?>
	<tr style="color: white">
		<td><?= $i; ?></td>
		<td>
			<a href="ubah.php?id=<?= $row["id"]; ?>" style="color: red;">Ubah</a>
			<a href="hapus.php?id=<?= $row["id"]; ?>" style="color: red;">Hapus</a>
		</td>
		<td><?= $row["nim"]; ?></td>
		<td><?= $row["nama"]; ?></td>
		<td><?= $row["semester"]; ?></td>
	</tr>
	<?php $i++; ?>
<?php endforeach; ?>
</table>
</center>
</body>
</html>