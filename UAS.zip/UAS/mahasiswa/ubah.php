<?php 
require 'functions.php';

$id = $_GET["id"];

$mhs = query("SELECT * FROM mahasiswa WHERE id = $id")[0];

if( isset($_POST["submit"]) ){
	if( ubah($_POST) > 0) {
		echo "
		<script>
			alert('Data berhasil diubah');
			document.location.href = 'index.php';
		</script>
			";
	} else {
		echo "
		<script>
			alert('Data gagal diubah');
			document.location.href = 'index.php';
		</script>
			";
	}

}

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Ubah Data Mahasiswa</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<h1>Ubah Data Mahasiswa</h1>

	<form action="" method="post">
		<input type="hidden" name="id" value="<?= $mhs["id"]; ?>">
		<ul>
			<li>
				<label for="nim">NIM : </label>
				<input type="text" name="nim" id="nim" required value="<?= $mhs["nim"]; ?>">
			</li><br>
			<li>
				<label for="nama">Nama : </label>
				<input type="text" name="nama" id="nama" required value="<?= $mhs["nama"]; ?>">
			</li><br>
			<li>
				<label for="semester">Semester : </label>
				<input type="text" name="semester" id="semester" required value="<?= $mhs["semester"]; ?>">
			</li><br>
			<li>
				<button type="submit" name="submit">
					Ubah Data
				</button>
			</li>
		</ul>


	</form>

</body>
</html>