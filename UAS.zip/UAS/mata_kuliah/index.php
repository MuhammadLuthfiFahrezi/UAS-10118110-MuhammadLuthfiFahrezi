<?php 
require 'functions.php';
$mata_kuliah = query("SELECT * FROM mata_kuliah");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<center>
<h1 style="color: white">Daftar Mata Kuliah</h1>

<a href="tambah.php" style="color: white">Tambah Data Mata Kuliah</a>
<br><br>

<table border="1" cellpadding="10" cellspacing="0">
	
	<tr style="color: white">
		<th>No.</th>
		<th>Aksi</th>
		<th>Kode Mata Kuliah</th>
		<th>Nama Mata Kuliah</th>
		<th>SKS</th>
	</tr>

<?php $i = 1; ?>
<?php foreach($mata_kuliah as $row) : ?>
	<tr style="color: white">
		<td><?= $i; ?></td>
		<td>
			<a href="ubah.php?id=<?= $row["id"]; ?>" style="color: red">Ubah</a>
			<a href="hapus.php?id=<?= $row["id"]; ?>" style="color: red">Hapus</a>
		</td>
		<td><?= $row["kode_mk"]; ?></td>
		<td><?= $row["nama_mk"]; ?></td>
		<td><?= $row["sks"]; ?></td>
	</tr>
	<?php $i++; ?>
<?php endforeach; ?>
</table>
</center>
</body>
</html>