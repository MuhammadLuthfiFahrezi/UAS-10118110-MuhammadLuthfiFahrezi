<?php 
require 'functions.php';

if( isset($_POST["submit"]) ){
	if( tambah($_POST) > 0) {
		echo "
		<script>
			alert('Data berhasil ditambahkan');
			document.location.href = 'index.php';
		</script>
			";
	} else {
		echo "
		<script>
			alert('Data gagal ditambahkan');
			document.location.href = 'index.php';
		</script>
			";
	}

}

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Tambah Data Mata Kuliah</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<h1>Tambah Data Mata Kuliah</h1>

	<form action="" method="post">
		<ul>
			<li>
				<label for="kode_mk">Kode Mata Kuliah : </label>
				<input type="text" name="kode_mk" id="kode_mk" required>
			</li><br>
			<li>
				<label for="nama_mk">Nama Mata Kuliah : </label>
				<input type="text" name="nama_mk" id="nama_mk" required>
			</li><br>
			<li>
				<label for="sks">SKS : </label>
				<input type="text" name="sks" id="sks" required>
			</li><br>
			<li>
				<button type="submit" name="submit">
					Tambah Data
				</button>
			</li>
		</ul>


	</form>

</body>
</html>