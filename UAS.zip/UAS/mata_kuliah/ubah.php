<?php 
require 'functions.php';

$id = $_GET["id"];

$mk = query("SELECT * FROM mata_kuliah WHERE id = $id")[0];

if( isset($_POST["submit"]) ){
	if( ubah($_POST) > 0) {
		echo "
		<script>
			alert('Data berhasil diubah');
			document.location.href = 'index.php';
		</script>
			";
	} else {
		echo "
		<script>
			alert('Data gagal diubah');
			document.location.href = 'index.php';
		</script>
			";
	}

}

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Ubah Data Mata Kuliah</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<h1>Ubah Data Mata Kuliah</h1>

	<form action="" method="post">
		<input type="hidden" name="id" value="<?= $mk["id"]; ?>">
		<ul>
			<li>
				<label for="kode_mk">Kode Mata Kuliah : </label>
				<input type="text" name="kode_mk" id="kode_mk" required value="<?= $mk["kode_mk"]; ?>">
			</li><br>
			<li>
				<label for="nama_mk">Nama Mata Kuliah : </label>
				<input type="text" name="nama_mk" id="nama_mk" required value="<?= $mk["nama_mk"]; ?>">
			</li><br>
			<li>
				<label for="sks">SKS : </label>
				<input type="text" name="sks" id="sks" required value="<?= $mk["sks"]; ?>">
			</li><br>
			<li>
				<button type="submit" name="submit">
					Ubah Data
				</button>
			</li>
		</ul>


	</form>

</body>
</html>